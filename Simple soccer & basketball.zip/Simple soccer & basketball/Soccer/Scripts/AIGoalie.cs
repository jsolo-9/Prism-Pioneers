using UnityEngine;
using UnityEngine;

public class AIGoalie : MonoBehaviour
{
    public Transform ballTransform; // Reference to the soccer ball's transform
    public float movementSpeed = 5f; // Adjust the movement speed as needed

    private Vector3 lastBallPosition; // Store the previous position of the ball

    private void Start()
    {
        if (ballTransform != null)
        {
            lastBallPosition = ballTransform.position;
        }
    }

    private void LateUpdate()
    {
        if (ballTransform != null && ballTransform.position != lastBallPosition)
        {
            Vector3 desiredPosition = CalculateDesiredPosition();
            MoveTowardsPosition(desiredPosition);
            lastBallPosition = ballTransform.position; // Update the last ball position
        }
    }

    private void MoveTowardsPosition(Vector3 targetPosition)
    {
        Vector3 moveDirection = (targetPosition - transform.position).normalized;
        float movementStep = movementSpeed * Time.deltaTime;
        Vector3 newPosition = transform.position + moveDirection * movementStep;
        transform.position = newPosition;
    }

    private Vector3 CalculateDesiredPosition()
    {
        // Implement your logic to calculate the desired position the goalie should move towards
        // This can be based on the ball's position, direction, and the goal's position
        // Modify this logic to suit your game's mechanics

        // Example: Move goalie directly towards the ball's position
        return ballTransform.position;
    }
}
